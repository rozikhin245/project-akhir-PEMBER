package com.example.tugasakhir.Data

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tugasakhir.Data.room.PostinganDao
import com.example.tugasakhir.Data.room.PostinganEntity
import com.example.tugasakhir.Data.room.ProfileEntity
import kotlinx.coroutines.launch

class AppViewModel(private val appRepository: AppRepository) : ViewModel() {

    fun getUserById(id: Int): LiveData<ProfileEntity> {
        // Menjalankan operasi insert di thread yang berbeda
        return appRepository.getUserById(id)
    }

    fun insertProfile(Profile: ProfileEntity)  {
        viewModelScope.launch {
            appRepository.insertProfile(Profile)
        }
    }

    // Mendapatkan semua data pemain dari database
    fun getAllPlayer(): LiveData<List<PostinganEntity>> {
        return appRepository.getPostingan()
    }

    fun insertPostingan(Postingan: PostinganEntity) {
        viewModelScope.launch {
            appRepository.insertPostingan(Postingan)
        }
    }

    fun updatePostingan(Postingan: PostinganEntity) {
        viewModelScope.launch {
            appRepository.updatePostingan(Postingan)
        }
    }

    fun deletePostingan(Postingan: PostinganEntity) {
        viewModelScope.launch {
            appRepository.deletPostingan(Postingan)
        }
    }
}