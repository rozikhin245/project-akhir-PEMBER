package com.example.tugasakhir.Activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tugasakhir.Adapter.PostinganAdapterRoom
import com.example.tugasakhir.Data.AppPreferences
import com.example.tugasakhir.Data.AppViewModel
import com.example.tugasakhir.Data.AppViewModelFactory
import com.example.tugasakhir.Data.room.PostinganEntity
import com.example.tugasakhir.R
import com.google.android.material.imageview.ShapeableImageView

class HalamanUtama : AppCompatActivity() {
    // Deklarasi variabel untuk ViewModel, Adapter, dan RecyclerView
    private lateinit var postViewModel: AppViewModel
    private lateinit var postAdapterRoom: PostinganAdapterRoom
    private lateinit var recyclerView: RecyclerView
    private lateinit var textViewName: TextView
    private lateinit var profileImage: ShapeableImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_halaman_utama)

        val addPostButton: com.google.android.material.floatingactionbutton.FloatingActionButton = findViewById(R.id.btn_addPost)
        addPostButton.setOnClickListener {
            val intent = Intent(this, AddPostingan::class.java)
            startActivity(intent)
        }

        // Inisialisasi ViewModel menggunakan ViewModelFactory
        val factory = AppViewModelFactory.getInstance(this)
        postViewModel = ViewModelProvider(this, factory)[AppViewModel::class.java]

        // Inisialisasi RecyclerView dan mengatur layout manager
        recyclerView = findViewById(R.id.rvPlayer)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Get Login User Id
        val loggedInUserId = AppPreferences(this@HalamanUtama).getUserId()

        textViewName = findViewById(R.id.textView21)
        profileImage = findViewById(R.id.imageProfile)

        // Get User Entity
        postViewModel.getUserById(loggedInUserId).observe(this) {
            it?.let {
                textViewName.text = it.nama
            }
        }

        profileImage.setOnClickListener {
            val intent = Intent(this@HalamanUtama, ProfileActivity::class.java)
            startActivity(intent)
        }

        // Mengamati perubahan data pada ViewModel dan mengatur Adapter untuk RecyclerView
        postViewModel.getAllPlayer().observe(this) { postData ->
            if (postData != null) {
                postAdapterRoom = PostinganAdapterRoom(postData) //inisialisasi adapter dengan data
                recyclerView.adapter = postAdapterRoom

                // Menetapkan callback untuk menangani klik item pada RecyclerView
                postAdapterRoom.setOnItemClickCallback(object : PostinganAdapterRoom.OnItemClickCallback {
                    override fun onItemClicked(data: PostinganEntity) {
                        val intent = Intent(this@HalamanUtama, DetailActivity::class.java)
                        intent.putExtra("image", data.image)  // Mengirimkan data ke DetailActivity
                        intent.putExtra("namaLokasi", data.namaLokasi)
                        intent.putExtra("deskripsi", data.deskripsi)
                        intent.putExtra("lokasi", data.lokasi)
                        intent.putExtra("rating", data.rating)
                        startActivity(intent)
                    }

                    override fun onOptionClicked(data: PostinganEntity) {
                        // Menampilkan PopUpFragment ketika item diklik
                        PopUpFragment(data).show(supportFragmentManager, PopUpFragment.TAG)
                    }
                })
            }
        }
    }

    fun toAddPost(view: View) {
        val intent = Intent(this, AddPostingan::class.java)
        startActivity(intent)
    }
}
