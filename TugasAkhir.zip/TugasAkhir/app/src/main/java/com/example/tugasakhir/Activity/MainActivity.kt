package com.example.tugasakhir.Activity

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.tugasakhir.Data.AppPreferences
import com.example.tugasakhir.Data.AppViewModel
import com.example.tugasakhir.Data.AppViewModelFactory
import com.example.tugasakhir.Data.retrofit.APIConfig
import com.example.tugasakhir.Data.retrofit.UserEntity
import com.example.tugasakhir.Data.room.ProfileDao
import com.example.tugasakhir.Data.room.ProfileDatabase
import com.example.tugasakhir.Data.room.ProfileEntity
import com.example.tugasakhir.R
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var appViewModel: AppViewModel
    private lateinit var profileDatabase: ProfileDatabase
    private lateinit var userDao: ProfileDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        usernameEditText = findViewById(R.id.username)
        passwordEditText = findViewById(R.id.password)
        loginButton = findViewById(R.id.loginButton)


        profileDatabase = ProfileDatabase.getDatabase(this)
        userDao = profileDatabase.ProfileDao()

        // Inisialisasi view model
        val factory = AppViewModelFactory.getInstance(this)
        appViewModel = ViewModelProvider(this, factory).get(AppViewModel::class.java)

        loginButton.setOnClickListener {
            loginUser()
        }
    }

    private fun loginUser() {
        val username = usernameEditText.text.toString()
        val password = passwordEditText.text.toString()

        if (username.isNotEmpty() && password.isNotEmpty()) {
            val apiService = APIConfig.getApiService()
            val call = apiService.getAllUsers()

            call.enqueue(object : Callback<List<UserEntity>> {
                override fun onResponse(call: Call<List<UserEntity>>, response: Response<List<UserEntity>>) {
                    if (response.isSuccessful) {
                        val users = response.body()

                        val user = users?.find { it.email == username && it.password == password }
                        if (user != null) {
                            val nama = user.nama
                            val tanggalLahir = user.tanggal_lahir
                            val jenkel = user.jenis_kelamin
                            val no_Telp = user.no_telp
                            val password = user.password
                            val email = user.email
                            val id = user.id
                            Toast.makeText(this@MainActivity, "Login Berhasil", Toast.LENGTH_SHORT).show()


                            val profile = ProfileEntity(
                                id = id,
                                nama = user.nama,
                                tanggal_lahir = user.tanggal_lahir,
                                jenis_kelamin = user.jenis_kelamin,
                                no_telp = user.no_telp,
                                password = user.password,
                                email = user.email
                            )

                            val intent = Intent(this@MainActivity, Dashbord::class.java)
                            startActivity(intent)

                            // Simpan user id ke dalam shared preferences
                            AppPreferences(this@MainActivity).saveUserId(id)

                            // Menyimpan data pemain ke database
                            if (profile != null) appViewModel.insertProfile(profile)


                        } else {
                            Toast.makeText(this@MainActivity, "Invalid Username or Password", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(this@MainActivity, "Login gagal", Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onFailure(call: Call<List<UserEntity>>, t: Throwable) {
                    Toast.makeText(this@MainActivity, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
                }
            })
        } else {
            Toast.makeText(this, "Username and Password must not be empty", Toast.LENGTH_SHORT).show()
        }
    }
}
