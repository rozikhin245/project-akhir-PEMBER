package com.example.tugasakhir.Data

import androidx.lifecycle.LiveData
import com.example.tugasakhir.Data.retrofit.UserEntity
import com.example.tugasakhir.Data.room.PostinganDao
import com.example.tugasakhir.Data.room.PostinganEntity
import com.example.tugasakhir.Data.room.ProfileDao
import com.example.tugasakhir.Data.room.ProfileEntity
import com.example.tugasakhir.Utils.AppExecutors

class AppRepository private constructor(private val PostinganDao: PostinganDao, private val profileDao: ProfileDao, private val appExecutors: AppExecutors) {

    fun getPostingan(): LiveData<List<PostinganEntity>> = PostinganDao.getAllPostingan()

    fun getUserById(id: Int): LiveData<ProfileEntity> {
        // Menjalankan operasi insert di thread yang berbeda
        return profileDao.getUserById(id)
    }

    // Memasukkan data Postingan ke dalam databas
    fun insertProfile(profile: ProfileEntity) {
        // Menjalankan operasi insert di thread yang berbeda
        appExecutors.diskIO().execute { profileDao.insertProfile(profile) }
    }


    // Memasukkan data Postingan ke dalam databas
    fun insertPostingan(Postingan: PostinganEntity) {
        // Menjalankan operasi insert di thread yang berbeda
        appExecutors.diskIO().execute { PostinganDao.insertPostingan(Postingan) }
    }

    // Delete data pemain ke dalam database
    fun deletPostingan(player: PostinganEntity) {
        // Menjalankan operasi insert di thread yang berbeda
        appExecutors.diskIO().execute { PostinganDao.deletePostingan(player) }
    }

    // Memperbarui data post dalam database
    fun updatePostingan(player: PostinganEntity) {
        // Menjalankan operasi update di thread yang berbeda
        appExecutors.diskIO().execute { PostinganDao.updatePostingan(player) }
    }

    companion object {
        // Variabel untuk menyimpan instance dari AppRepository
        @Volatile
        private var instance: AppRepository? = null

        // Mendapatkan instance dari AppRepository
        fun getInstance(
            profileDao: ProfileDao,
            postinganDao: PostinganDao,
            appExecutors: AppExecutors
        ): AppRepository =
            // Jika instance null, maka akan dibuat instance baru
            instance ?: synchronized(this) {
                instance ?: AppRepository(postinganDao, profileDao, appExecutors)
            }.also { instance = it }
    }
}