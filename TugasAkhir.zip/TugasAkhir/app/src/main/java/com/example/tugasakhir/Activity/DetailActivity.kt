package com.example.tugasakhir.Activity

import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide
import com.example.tugasakhir.R

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_detail)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        // Get data from the intent
        val imageUri = intent.getStringExtra("image")
        val namaLokasi = intent.getStringExtra("namaLokasi")
        val lokasi = intent.getStringExtra("lokasi")
        val deskripsi = intent.getStringExtra("deskripsi")
        val rating = intent.getFloatExtra("rating", 0.0f)

        // Display the data
        val imageView: ImageView = findViewById(R.id.gambarPostingan)
        val namaLokasiTextView: TextView = findViewById(R.id.namaPostingan)
        val lokasiTextView: TextView = findViewById(R.id.lokasiPostingan)
        val deskripsiTextView: TextView = findViewById(R.id.detailPostingan)
        val ratingTextView: TextView = findViewById(R.id.ratingg)

        if (imageUri != null) {
            Glide.with(this).load(Uri.parse(imageUri)).into(imageView)
        }

        // Set the text views with the retrieved data
        namaLokasiTextView.text = namaLokasi
        lokasiTextView.text = lokasi
        deskripsiTextView.text = deskripsi
        ratingTextView.text = rating.toString()
    }
}
