package com.example.tugasakhir.Adapter

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.tugasakhir.Data.room.PostinganEntity
import com.example.tugasakhir.R
import com.google.android.material.imageview.ShapeableImageView

class PostinganAdapterRoom(private var PostList: List<PostinganEntity>) :
    RecyclerView.Adapter<PostinganAdapterRoom.PostinganViewHolder>() {
    private lateinit var onItemClickCallback: OnItemClickCallback


    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: PostinganEntity)
        fun onOptionClicked(data: PostinganEntity)
    }
    // Kelas ViewHolder untuk menyimpan referensi view yang digunakan dalam RecyclerView
    class PostinganViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        //penginialisasi konten
        val Gambarnya: ImageView = itemView.findViewById(R.id.player_image)
        val Namannya: TextView = itemView.findViewById(R.id.materialTextView2)

        val Lokasinya: TextView = itemView.findViewById(R.id.materialTextView3)
        val opsi: ShapeableImageView = itemView.findViewById(R.id.opsi)

        //button
//        val btnMore: ImageView = itemView.findViewById(R.id.opsi)
    }

    // Menginflate layout item_postingan.xml dan mengembalikan ViewHolder
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostinganViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_item, parent, false) // Replace with your actual layout
        return PostinganViewHolder(view)
    }

    // Fungsi untuk mengikat data dengan ViewHolder (memasukkan data yang kita miliki ke dalam XML ViewHolder)
    override fun onBindViewHolder(holder: PostinganViewHolder, position: Int) {
        val data = PostList[position]
        // Mengikat data dari PostinganEntity ke elemen UI di ViewHolder
        holder.Namannya.text = data.namaLokasi
        holder.Lokasinya.text = data.lokasi

        //menambahkan data ke dalam gambar
        val uri = Uri.fromFile(data.image)
        holder.Gambarnya.setImageURI(uri)

//        // Mengatur aksi like ketika item diklik
//        holder.btnLike.setOnClickListener {
//            data.like += 1
//            holder.postLike.text = data.like.toString()
//        }
        // Mengatur aksi lainnya ketika item diklik
        holder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(data)}
        holder.opsi.setOnClickListener { onItemClickCallback.onOptionClicked(data) }
    }

    // Fungsi untuk mendapatkan jumlah item
    override fun getItemCount(): Int = PostList.size

    fun updatePosts(posts: List<PostinganEntity>) {
        PostList = posts
        notifyDataSetChanged()
    }
    // Fungsi untuk memendekkan teks jika melebihi panjang maksimum
    private fun String.shorten(maxLength: Int): String {
        return if (this.length <= maxLength) this else "${this.substring(0, maxLength)}..."
    }
}