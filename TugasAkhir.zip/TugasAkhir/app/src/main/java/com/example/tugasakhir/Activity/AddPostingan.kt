package com.example.tugasakhir.Activity

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.esafirm.imagepicker.features.ImagePickerConfig
import com.esafirm.imagepicker.features.ImagePickerMode
import com.esafirm.imagepicker.features.ReturnMode
import com.esafirm.imagepicker.features.registerImagePicker
import com.example.tugasakhir.Data.AppViewModel
import com.example.tugasakhir.Data.AppViewModelFactory
import com.example.tugasakhir.Data.room.PostinganEntity
import com.example.tugasakhir.R
import com.example.tugasakhir.Utils.reduceFileImage
import com.example.tugasakhir.Utils.uriToFile
import java.io.File
import kotlin.random.Random

class AddPostingan : AppCompatActivity() {

    private var currentImageUri: Uri? = null
    private lateinit var postViewModel: AppViewModel
    private lateinit var namatempatEditText: EditText
    private lateinit var LokaisEditText: EditText
    private lateinit var deskripsiEditText: EditText
    private lateinit var vPostImage: ImageView
    private lateinit var psotingutton: Button

    // Mendeklarasikan image picker untuk memilih gambar pada galeri di hp
    private val imagePickerLauncher = registerImagePicker {
        val firstImage = it.firstOrNull() ?: return@registerImagePicker
        if (firstImage.uri.toString().isNotEmpty()) {
            vPostImage.visibility = View.VISIBLE
            currentImageUri = firstImage.uri
            Glide.with(vPostImage)
                .load(firstImage.uri)
                .into(vPostImage)
        } else {
            vPostImage.visibility = View.GONE
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tambahpost)

        val rating = 2.5
        val like = 0

        val factory = AppViewModelFactory.getInstance(this)
        postViewModel = ViewModelProvider(this, factory)[AppViewModel::class.java]

        // Mengambil TextInputEditText dari TextInputLayout
        namatempatEditText = findViewById(R.id.nama_tempat)
        LokaisEditText = findViewById(R.id.lokasi)
        deskripsiEditText = findViewById(R.id.post_desc_edit)
        psotingutton = findViewById(R.id.btn_savedPost)
        vPostImage = findViewById(R.id.post_img_edit)

        // Set onClickListeners
        onClick()
    }

    private fun onClick() {
        vPostImage.setOnClickListener {
            imagePickerLauncher.launch(
                ImagePickerConfig {
                    mode = ImagePickerMode.SINGLE
                    returnMode = ReturnMode.ALL
                    isFolderMode = true
                    folderTitle = "Galeri Perangkat"
                    isShowCamera = false
                    imageTitle = "Pilih gambar untuk diposting"
                    doneButtonText = "Done"
                }
            )
        }

        val btnSavedPlayer = findViewById<Button>(R.id.btn_savedPost)
        btnSavedPlayer.setOnClickListener {
            if (validateInput()) {
                saveData()
            }
        }
    }

    private fun validateInput(): Boolean {
        var error = 0

        if (namatempatEditText.text.toString().isEmpty()) {
            error++
            namatempatEditText.error = "Isi Dulu Nama Lokasinya!"
        }

        if (LokaisEditText.text.toString().isEmpty()) {
            error++
            LokaisEditText.error = "Isi Dulu Deskripsinya!"
        }

        if (deskripsiEditText.text.toString().isEmpty()) {
            error++
            deskripsiEditText.error = "Isi Dulu Lokasinya!"
        }

        if (currentImageUri == null) {
            error++
            Toast.makeText(this, "Masukkan gambar dulu!", Toast.LENGTH_SHORT).show()
        }

        return error == 0
    }

    private fun saveData() {
        val imageFile = currentImageUri?.let { uriToFile(it, this).reduceFileImage() }
        val postinganEntity = imageFile?.let {
            PostinganEntity(
                image = it,
                namaLokasi = namatempatEditText.text.toString(),
                deskripsi = deskripsiEditText.text.toString(),
                suka = Random.nextInt(0, 9),
                lokasi = LokaisEditText.text.toString(),
                rating = 2.5f //
            )
        }

        if (postinganEntity != null) {
            postViewModel.insertPostingan(postinganEntity)
            Toast.makeText(this, "Data Berhasil Ditambah", Toast.LENGTH_SHORT).show()

            // Create an Intent to pass data to DetailActivity
            val intent = Intent(this, DetailActivity::class.java).apply {
                putExtra("image", postinganEntity.image.path)
                putExtra("namaLokasi", postinganEntity.namaLokasi)
                putExtra("deskripsi", postinganEntity.deskripsi)
                putExtra("suka", postinganEntity.suka)
                putExtra("lokasi", postinganEntity.lokasi)
                putExtra("rating", postinganEntity.rating)
            }

        }
    }

    fun backadd(view: View) {
        val intent = Intent(this, HalamanUtama::class.java)
        startActivity(intent)
    }
}
