package com.example.tugasakhir.Data

import android.content.Context

class AppPreferences(private val context: Context) {

    private val pref = context.getSharedPreferences("tugasakhir", Context.MODE_PRIVATE)
    private val edit = pref.edit()

    fun saveUserId(userId: Int) {
        edit.putInt("userId", userId)
        edit.apply()
    }

    fun getUserId(): Int {
        return pref.getInt("userId", 0)
    }
}