package com.example.tugasakhir.Data.room

import android.os.Parcel
import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.File

@Entity
data class PostinganEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val image: File,
    val namaLokasi: String,
    val deskripsi: String,
    val suka: Int,
    val lokasi: String,
    val rating: Float
) : Parcelable {

    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        File(parcel.readString()!!),
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readInt(),
        parcel.readString()!!,
        parcel.readFloat()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(id)
        parcel.writeString(image.path)
        parcel.writeString(namaLokasi)
        parcel.writeString(deskripsi)
        parcel.writeInt(suka)
        parcel.writeString(lokasi)
        parcel.writeFloat(rating)
    }

    // Fungsi untuk mendeskripsikan jenis konten khusus yang ditangani oleh Parcelable
    override fun describeContents(): Int {
        return 0
    }

    // Objek pendamping untuk PlayerDatabase yang berisi fungsi untuk membuat objek PlayerDatabase dari Parcel dan Array
    companion object CREATOR : Parcelable.Creator<PostinganEntity> {
        // Fungsi untuk membuat objek PlayerDatabase dari Parcel
        override fun createFromParcel(parcel: Parcel): PostinganEntity {
            return PostinganEntity(parcel)
        }

        // Fungsi untuk membuat array dari objek PlayerDatabase
        override fun newArray(size: Int): Array<PostinganEntity?> {
            return arrayOfNulls(size)
        }
    }
}