package com.example.tugasakhir.Data.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.tugasakhir.Data.retrofit.UserEntity
import com.example.tugasakhir.Utils.converter

@Database(entities = [PostinganEntity::class, ProfileEntity::class], version = 2)
@TypeConverters(converter::class)
abstract class ProfileDatabase : RoomDatabase() {
    abstract fun ProfileDao(): ProfileDao

    companion object {
        @Volatile
        private var INSTANCE: ProfileDatabase? = null

        fun getDatabase(context: Context): ProfileDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ProfileDatabase::class.java,
                    "user_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
