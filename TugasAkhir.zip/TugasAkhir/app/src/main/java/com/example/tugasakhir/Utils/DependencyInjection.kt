package com.example.tugasakhir.Utils

import android.content.Context
import com.example.tugasakhir.Data.AppRepository
import com.example.tugasakhir.Data.room.AppDatabase
import com.example.tugasakhir.Data.room.PostinganDao
import com.example.tugasakhir.Data.room.ProfileDao
import com.example.tugasakhir.Data.room.ProfileDatabase


object DependencyInjection {

    fun provideRepository(context: Context) : AppRepository {
        val database = AppDatabase.getDatabase(context)
        val db_prof = ProfileDatabase.getDatabase(context)
        val appExecutors = AppExecutors()
        val Postingandao = database.postinganDao()
        val ProfileDao = db_prof.ProfileDao()
        return AppRepository.getInstance( ProfileDao,Postingandao, appExecutors)
    }

}