package com.example.tugasakhir.Data.retrofit

import retrofit2.Call
import retrofit2.http.GET

interface APIService {

    @GET("users")
    fun getAllUsers(): Call<List<UserEntity>>

}