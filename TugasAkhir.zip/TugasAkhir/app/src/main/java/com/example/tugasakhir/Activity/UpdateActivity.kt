package com.example.tugasakhir.Activity

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.esafirm.imagepicker.features.ImagePickerConfig
import com.esafirm.imagepicker.features.ImagePickerMode
import com.esafirm.imagepicker.features.ReturnMode
import com.esafirm.imagepicker.features.registerImagePicker
import com.example.tugasakhir.Data.AppViewModel
import com.example.tugasakhir.Data.AppViewModelFactory
import com.example.tugasakhir.Data.room.PostinganEntity
import com.example.tugasakhir.R
import com.example.tugasakhir.Utils.reduceFileImage
import com.example.tugasakhir.Utils.uriToFile
import java.io.File
import kotlin.random.Random

class UpdateActivity : AppCompatActivity() {
    private var acurrentImageUri: Uri? = null
    private var oldPhoto: File? = null
    private lateinit var apostViewModel: AppViewModel
    private lateinit var anamatempatEditText: EditText
    private lateinit var aLokaisEditText: EditText
    private lateinit var adeskripsiEditText: EditText
    private lateinit var avPostImage: ImageView
    private lateinit var psotingutton: Button
    private lateinit var getData: PostinganEntity

    // Mendeklarasikan image picker untuk memilih gambar pada galeri di hp
    private val imagePickerLauncher = registerImagePicker {
        val firstImage = it.firstOrNull() ?: return@registerImagePicker
        if (firstImage.uri.toString().isNotEmpty()) {
            avPostImage.visibility = View.VISIBLE
            acurrentImageUri = firstImage.uri
            Glide.with(avPostImage)
                .load(firstImage.uri)
                .into(avPostImage)
        } else {
            avPostImage.visibility = View.GONE
        }
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update)

        getData = intent.getParcelableExtra("player")!!

        val factory = AppViewModelFactory.getInstance(this)
        apostViewModel = ViewModelProvider(this, factory)[AppViewModel::class.java]

        anamatempatEditText = findViewById(R.id.Update_nama_tempat)
        aLokaisEditText = findViewById(R.id.Update_lokasi)
        adeskripsiEditText = findViewById(R.id.Update_post_desc_edit)
        avPostImage = findViewById(R.id.Updatepost_img_edit)
        psotingutton = findViewById(R.id.btnUpdate)

        oldPhoto = getData.image

        Glide.with(avPostImage)
            .load(getData.image)
            .into(avPostImage)

        onClick()

        // Mengisi EditText dengan data yang ada
        anamatempatEditText.setText(getData.namaLokasi)
        aLokaisEditText.setText(getData.lokasi)
        adeskripsiEditText.setText(getData.deskripsi)

        // Mengatur acurrentImageUri ke URI dari gambar lama
        acurrentImageUri = Uri.fromFile(getData.image)
    }

    private fun onClick() {
        avPostImage.setOnClickListener {
            imagePickerLauncher.launch(
                ImagePickerConfig {
                    mode = ImagePickerMode.SINGLE
                    returnMode = ReturnMode.ALL
                    isFolderMode = true
                    folderTitle = "Galeri Perangkat"
                    isShowCamera = false
                    imageTitle = "Pilih gambar untuk diposting"
                    doneButtonText = "Done"
                }
            )
        }

        psotingutton.setOnClickListener {
            if (validateInput()) {
                saveData()
            }
        }
    }

    private fun validateInput(): Boolean {
        var error = 0

        if (anamatempatEditText.text.toString().isEmpty()) {
            error++
            anamatempatEditText.error = "Isi Dulu Nama Lokasinya!"
        }

        if (aLokaisEditText.text.toString().isEmpty()) {
            error++
            aLokaisEditText.error = "Isi Dulu Deskripsinya!"
        }

        if (adeskripsiEditText.text.toString().isEmpty()) {
            error++
            adeskripsiEditText.error = "Isi Dulu Lokasinya!"
        }

        if (acurrentImageUri == null) {
            error++
            Toast.makeText(this, "Masukkan gambar dulu!", Toast.LENGTH_SHORT).show()
        }

        return error == 0
    }

    private fun saveData() {
        val imageFile = acurrentImageUri?.let { uriToFile(it, this)?.reduceFileImage() }
        val postinganEntity = imageFile?.let {
            PostinganEntity(
                id = getData.id,
                image = it,
                namaLokasi = anamatempatEditText.text.toString(),
                deskripsi = adeskripsiEditText.text.toString(),
                suka = getData.suka,
                lokasi = aLokaisEditText.text.toString(),
                rating = getData.rating
            )
        }

        postinganEntity?.let {
            apostViewModel.updatePostingan(it)
            Toast.makeText(this, "Data Berhasil Diupdate", Toast.LENGTH_SHORT).show()
            finish()
        } ?: run {
            Toast.makeText(this, "Gagal menyimpan data", Toast.LENGTH_SHORT).show()
        }
    }
}
