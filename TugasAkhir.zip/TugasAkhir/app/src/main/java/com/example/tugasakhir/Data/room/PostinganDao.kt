package com.example.tugasakhir.Data.room

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface PostinganDao {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertPostingan(player: PostinganEntity)

    @Query("SELECT * FROM PostinganEntity ORDER BY id DESC")
    fun getAllPostingan() : LiveData<List<PostinganEntity>>

    @Update
    fun updatePostingan(post: PostinganEntity)

    @Delete
    fun deletePostingan(post: PostinganEntity)
}