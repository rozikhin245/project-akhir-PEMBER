package com.example.tugasakhir.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.tugasakhir.Data.retrofit.UserEntity
import com.example.tugasakhir.R

class UserAdapter(private val userList: List<UserEntity>) : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: UserEntity)
    }

    // Kelas ViewHolder untuk menyimpan referensi view yang digunakan dalam RecyclerView
    class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val namaTextView: TextView = itemView.findViewById(R.id.namaTextView)
        val tanggalLahirTextView: TextView = itemView.findViewById(R.id.tanggalLahirTextView)
        val jenisKelaminTextView: TextView = itemView.findViewById(R.id.textView13)
        val noTelpTextView: TextView = itemView.findViewById(R.id.noTelpTextView)
        val emailTextView: TextView = itemView.findViewById(R.id.emailTextView)
    }

    // Fungsi untuk membuat ViewHolder (Melakukan setting untuk XML yang akan kita gunakan untuk menampilkan data)
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.activity_main, parent, false)
        return UserViewHolder(view)
    }

    // Fungsi untuk mengikat data dengan ViewHolder (memasukkan data yang kita miliki ke dalam XML ViewHolder)
    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = userList[position]
        holder.namaTextView.text = user.nama
        holder.tanggalLahirTextView.text = user.tanggal_lahir
        holder.jenisKelaminTextView.text = user.jenis_kelamin
        holder.noTelpTextView.text = user.no_telp
        holder.emailTextView.text = user.email


    }

    // Fungsi untuk mendapatkan jumlah item
    override fun getItemCount(): Int {
        return userList.size
    }

    // Fungsi untuk memendekkan teks jika melebihi panjang maksimum
    private fun String.shorten(maxLength: Int): String {
        return if (this.length <= maxLength) this else "${this.substring(0, maxLength)}..."
    }
}
