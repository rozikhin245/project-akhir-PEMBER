package com.example.tugasakhir.Activity

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import com.example.tugasakhir.Data.AppPreferences
import com.example.tugasakhir.Data.retrofit.UserEntity
import com.example.tugasakhir.Data.room.ProfileDao
import com.example.tugasakhir.Data.room.ProfileDatabase
import com.example.tugasakhir.Data.room.ProfileEntity
import com.example.tugasakhir.R
class ProfileActivity : AppCompatActivity() {
    private lateinit var userDao: ProfileDao
    private lateinit var userLiveData: LiveData<ProfileEntity>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        val db = ProfileDatabase.getDatabase(this)
        userDao = db.ProfileDao()

        // Mengambil user ID dari SharedPreferences
        val userId = AppPreferences(this@ProfileActivity).getUserId()

        if (userId != -1) {
            // Mengambil data pengguna dari Room Database berdasarkan user ID
            userLiveData = userDao.getUserById(userId)
            userLiveData.observe(this, Observer { user ->
                if (user != null) {
                    // Update UI dengan data pengguna
                    findViewById<TextView>(R.id.namaTextView).text = user.nama
                    findViewById<TextView>(R.id.tanggalLahirTextView).text = user.tanggal_lahir
                    findViewById<TextView>(R.id.textView13).text = user.jenis_kelamin
                    findViewById<TextView>(R.id.noTelpTextView).text = user.no_telp
                    findViewById<TextView>(R.id.emailTextView).text = user.email
                }
            })
        }
    }
}
