package com.example.tugasakhir.Data.retrofit

data class UserEntity(
    val nama: String,
    val tanggal_lahir: String,
    val jenis_kelamin: String,
    val no_telp: String,
    val password: String,
    val email: String,
    val id: Int
)
