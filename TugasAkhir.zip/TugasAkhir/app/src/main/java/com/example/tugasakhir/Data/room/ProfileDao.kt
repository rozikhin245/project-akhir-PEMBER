package com.example.tugasakhir.Data.room

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.tugasakhir.Data.retrofit.UserEntity

@Dao
interface ProfileDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertProfile(user: ProfileEntity)

    @Query("SELECT * FROM ProfileEntity WHERE id = :userId")
    fun getUserById(userId: Int): LiveData<ProfileEntity>

}