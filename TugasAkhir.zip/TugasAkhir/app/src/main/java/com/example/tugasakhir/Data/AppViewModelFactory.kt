package com.example.tugasakhir.Data

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.tugasakhir.Utils.DependencyInjection

class AppViewModelFactory private constructor(private val repository: AppRepository) : ViewModelProvider.NewInstanceFactory() {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AppViewModel::class.java)) {
            return AppViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
    }

    companion object {
        @Volatile
        private var instance: AppViewModelFactory? = null

        fun getInstance(context: Context): AppViewModelFactory =
            instance ?: synchronized(this) {
                instance ?: AppViewModelFactory(DependencyInjection.provideRepository(context))
            }.also { instance = it }
    }
}
